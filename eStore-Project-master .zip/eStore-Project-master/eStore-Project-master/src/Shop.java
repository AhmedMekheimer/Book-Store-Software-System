import java.util.ArrayList;

public class Shop {
  
    ArrayList<Category> department;
    ArrayList<Product> product;
    ArrayList<Reader> customer;
    ArrayList<Cart> cart;
}
