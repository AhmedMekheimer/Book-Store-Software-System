
import java.util.Collection;
import java.util.LinkedList;


class Product {

    String nameProdect;
    String authorName;

    double price;
    int quatiy;
    String descriptionProduct;
    String dep;

    public Product() {
    }

    public Product(String nameProdect, String authorName, double price, int quatiy, String descriptionProduct, String dep) {
        this.nameProdect = nameProdect;
        this.authorName = authorName;
        this.price = price;
        this.quatiy = quatiy;
        this.descriptionProduct = descriptionProduct;
        this.dep = dep;
    }

    

    public String getNameProdect() {
        return nameProdect;
    }

    public void setNameProdect(String nameProdect) {
        this.nameProdect = nameProdect;
    }

    public String getAuthorName() {
        return authorName;
    }

    public void setAuthorName(String authorName) {
        this.authorName = authorName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuatiy() {
        return quatiy;
    }

    public void setQuatiy(int quatiy) {
        this.quatiy = quatiy;
    }

    public String getDescriptionProduct() {
        return descriptionProduct;
    }

    public void setDescriptionProduct(String descriptionProduct) {
        this.descriptionProduct = descriptionProduct;
    }

    public String getDep() {
        return dep;
    }

    public void setDep(String dep) {
        this.dep = dep;
    }

}
