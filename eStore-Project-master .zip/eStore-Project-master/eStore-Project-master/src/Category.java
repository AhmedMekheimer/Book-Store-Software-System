import java.util.Collection;
import java.util.ArrayList;
import java.util.LinkedList;

public class Category {
  
 static Collection<String> nameDepatment  = new LinkedList();
    
 static Collection<String> description = new LinkedList();
 
 ArrayList<Product> product;

 static int size = 0;

    public Category(ArrayList<Product> product) {
        this.product = product;
    }

    public static Collection<String> getNameDepatment() {
        return nameDepatment;
    }

    public static void setNameDepatment(Collection<String> nameDepatment) {
        Category.nameDepatment = nameDepatment;
    }

    public static Collection<String> getDescription() {
        return description;
    }

    public static void setDescription(Collection<String> description) {
        Category.description = description;
    }

    public ArrayList<Product> getProduct() {
        return product;
    }

    public void setProduct(ArrayList<Product> product) {
        this.product = product;
    }
 
    
}
